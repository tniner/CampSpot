﻿namespace ParseJson
{
    public class Campsite
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}
